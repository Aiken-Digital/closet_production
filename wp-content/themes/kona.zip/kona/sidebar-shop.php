<?php
global $prefix;
?>

<div class="sidebar-inner">
	<?php  dynamic_sidebar('Shop Sidebar'); ?>
</div> <!-- END sidebar-inner -->