<?php if (get_the_post_thumbnail()) { ?>
<div class="blog-media">
	<?php the_post_thumbnail('kona-thumb-big'); ?>
</div> <!-- END .entry-media -->
<?php } ?>
