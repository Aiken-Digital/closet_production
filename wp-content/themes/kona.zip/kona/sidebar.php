<?php
global $prefix;
?>

<div class="sidebar-inner">
	<?php  dynamic_sidebar('Blog Sidebar'); ?>
</div> <!-- END sidebar-inner -->