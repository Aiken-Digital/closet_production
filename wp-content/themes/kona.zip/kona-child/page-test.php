<?php
    /*
        Template Name: PAGE TEST
    */
      $data = get_fields( 'options' );
     echo "<pre>";
     print_r(json_encode($data));;
?>

<table>
    <tr>
        <td></td>
        <td>
            6 Scotts Road <br>
            #03-10 Scotts Square <br>
            Singapore 228209
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            6444 8325 / 8522 3766
        </td>
    </tr>
    <tr>
        <td></td>
        <td>
            10.30 AM - 08.30 PM
        </td>
    </tr>
</table>

