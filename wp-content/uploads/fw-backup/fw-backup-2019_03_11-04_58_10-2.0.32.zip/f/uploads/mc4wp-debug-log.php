<?php exit; ?>
[2017-08-22 09:54:45] ERROR: Form 199 > MailChimp API error: 400 Bad Request. nguy************@gm***.com has signed up to a lot of lists very recently; we're not allowing more signups for now
[2017-08-22 09:59:31] ERROR: Form 199 > MailChimp API error: 400 Bad Request. nguy************@gm***.com has signed up to a lot of lists very recently; we're not allowing more signups for now
[2017-08-22 10:00:06] ERROR: Form 199 > MailChimp API error: 400 Bad Request. nguy************@gm***.com has signed up to a lot of lists very recently; we're not allowing more signups for now
[2017-08-22 10:02:50] ERROR: Form 199 > MailChimp API error: 400 Bad Request. nguy************@gm***.com has signed up to a lot of lists very recently; we're not allowing more signups for now
